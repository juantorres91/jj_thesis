from Tesis.Rheology.Ph_Gen   import *
from Tesis.Rheology.Dp_Size  import *
from Tesis.Rheology.Visco_model import *
from Tesis.Rheology.Thick    import *
